
<?php
include('../dbcon.php');

$id=$_GET['book'];

echo $id;	
$update1 = mysqli_query($conn,"UPDATE `service`  SET `level`= 1  WHERE id='$id'");
if($update1)
{	header('Location: home.php');
}
else {
	echo "No Data Found".mysql_error();
}

?>