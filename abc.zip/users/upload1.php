<?php
include('../dbcon.php');
	
$date=$_POST["date"];
$amount=$_POST["amount"];
$name=$_POST["name"];
$desc=$_POST["desc"];
echo $desc;

    //storing all necessary data into the respective variables.
$file = $_FILES['file'];
$file_name = $file['name'];
$file_type = $file ['type'];
$file_size = $file ['size'];
$file_path = $file ['tmp_name'];

//Restriction to the image. You can upload any types of file for example video file, mp3 file, .doc or .pdf just mention here in OR condition. 

if(move_uploaded_file ($file_path,'users/images/'.$file_name))//"images" is just a folder name here we will load the file.
{
$query=mysql_query("INSERT INTO `service`(`id`, `date`, `name`, `money`, `photo`) VALUES ('','$date','$name','$amount','$file_name')");//mysql command to insert file name with extension into the table. Use TEXT datatype for a particular column in table. 
}
if($query)
{
    echo "File Uploaded";
}


?>
