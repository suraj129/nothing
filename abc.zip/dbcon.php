<?php
$servername = "mysql.hostinger.in";
$username = "u751228095_abc";
$password = "123456";
$database = "u751228095_abc";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>
