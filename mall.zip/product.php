<!DOCTYPE html>
<html lang="en">
<head>
  <title>Mall Manegment System : Home </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style>
  body{font-family:'Open Sans Condensed',sans-serif;font-size:20px; background:#f8f8f8}
	 body {
		font-family: 'Open Sans', sans-serif;
		background: #092756;
		background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
		background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
		background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
		background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
		background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
	}
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */ 
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
  
    <h1>Mall Manegment System <h1>      
    
  </div>
</div>

<nav class="navbar navbar-inverse ">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Mall</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="home.html">Home</a></li>
        <li><a href="#">Events</a></li>
        <li><a href="#">Deals</a></li>
        <li><a href="#">Stores</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login_user.html">Sign In	</a></li>
		<li><a href="create_an_account.html">Sign Up</a></li>
   
      </ul>
    </div>
  </div>
</nav>
<?php
include('dbcon.php');
$counter = 0;
$select_post_per_users = mysqli_query($conn,"SELECT  `photo`,`name` FROM `service`");
if($select_post_per_users){
		
		while($array_get_users = mysqli_fetch_array($select_post_per_users)){
			$photo = $array_get_users['photo'];	
			$name = $array_get_users['name'];				
			$counter++;
			echo "<div class='container'>    
		<div class='row'>";
		if ($counter % 2 != 0)
		{
		echo "
		<div class='col-sm-5'>
		<div class='panel panel-primary'>
        <div class='panel-heading'>Event".$counter.	" </div>
        <div class='panel-body'><img src='users/images/".$photo."' class='img-responsive' style='width:70%;height:200px;' alt='Image'></div>
        <div class='panel-footer'>".$name."</div>
		</div>
		</div>";
		}
		
		if ($counter % 2 == 0)
		{
		echo "
		<div class='col-sm-5'>
		<div class='panel panel-primary'>
        <div class='panel-heading'>Event".$counter.	" </div>
        <div class='panel-body'><img src='users/images/".$photo."' class='img-responsive' style='width:70%;height:200px;' alt='Image'></div>
        <div class='panel-footer'>".$name."</div>
		</div>
		</div></div></div>";
		}
			}
}
?>
    







</body>
</html>
