<?php
session_start();
session_destroy();
header('LOCATION:../login_user.html');
?>