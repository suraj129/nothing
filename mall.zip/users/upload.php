<?php
$con= mysql_connect("localhost","root","");//keep password inside "" if you are using password for mysql
mysql_select_db("myproject",$con);//replace myproject with your database name.



    //storing all necessary data into the respective variables.
$file = $_FILES['file'];
$file_name = $file['name'];
$file_type = $file ['type'];
$file_size = $file ['size'];
$file_path = $file ['tmp_name'];

//Restriction to the image. You can upload any types of file for example video file, mp3 file, .doc or .pdf just mention here in OR condition. 
if(move_uploaded_file ($file_path,'video/'.$file_name))//"images" is just a folder name here we will load the file.
{
$query=mysql_query("INSERT INTO `video`(`id`,`name`) VALUES ('','$file_name')");//mysql command to insert file name with extension into the table. Use TEXT datatype for a particular column in table. 
}
if($query)
{
    echo "Deals Saved.";
	echo "<br><button><a href='home.php'>Back</a></button>";
}


?>
