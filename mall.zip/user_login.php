<?php
include('dbcon.php');

$num=$_POST["number"];
$password=$_POST["password"];
$cate = $_POST["cate"];


$sql = "SELECT name, password,id,cate FROM user WHERE id = '".$num."' AND password = '".$password."'";


$result = mysqli_query($conn, $sql);

error_reporting(0);

if (mysqli_num_rows($result)>0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result))
	{
        if($num == $row["id"] and $password == $row["password"] and $cate == $row["cate"])
		{
		$_SESSION['id']=$num;
		header('Location: users/home.php');
			}
		else if($num == $row["id"] and $password == $row["password"] and $cate == $row["cate"])
		{
		$_SESSION['id']=$num;
		header('Location: users/home.php');
			}
		else
		{
		echo "error";

		}
	}
}	

mysqli_close($conn);

				
?>
