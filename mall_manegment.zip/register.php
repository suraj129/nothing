<?php
include('dbcon.php');

$name=$_POST["name"];
$num=$_POST["num"];
$cate=$_POST['cate'];
$num1=$_POST['confirm'];

$insert_record="INSERT INTO `user`(`id`,`name`,`password`,`cate`) VALUES ('$num','$name','$num1','$cate')";
						
if (mysqli_query($conn, $insert_record)) {
	echo "<center><h3>Your Account Was Created .</h3></center>";
	
} else {
    echo "User Exits. ";
}


?>